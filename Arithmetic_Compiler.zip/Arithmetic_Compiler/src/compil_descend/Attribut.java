
package compil_descend;

public class Attribut {
    String type;
    float value; 
    
    public Attribut()
    {

    }
    public Attribut(String type, float value)
    {
        this.type=type;
        this.value=value;
    }
    
        public Attribut(String type, int value)
    {
        this.type=type;
        this.value=value;
    }
}
